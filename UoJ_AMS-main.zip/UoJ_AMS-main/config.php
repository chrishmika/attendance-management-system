<?php
define('ROOT_PATH', __DIR__);
define('SERVER_ROOT', '/MyAttendanceSys');
?>